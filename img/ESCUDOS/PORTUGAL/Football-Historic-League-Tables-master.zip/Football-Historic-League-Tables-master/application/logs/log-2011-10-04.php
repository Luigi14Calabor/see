<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-10-04 02:18:14 --> Config Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:18:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:18:14 --> URI Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Router Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Output Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Input Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:18:14 --> Language Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Loader Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Controller Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:18:14 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:18:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:18:15 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:18:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:18:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:18:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:18:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:18:15 --> Final output sent to browser
DEBUG - 2011-10-04 02:18:15 --> Total execution time: 1.3763
DEBUG - 2011-10-04 02:18:19 --> Config Class Initialized
DEBUG - 2011-10-04 02:18:19 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:18:19 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:18:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:18:19 --> URI Class Initialized
DEBUG - 2011-10-04 02:18:19 --> Router Class Initialized
ERROR - 2011-10-04 02:18:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 02:18:34 --> Config Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:18:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:18:34 --> URI Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Router Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Output Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Input Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:18:34 --> Language Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Loader Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Controller Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:18:34 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:18:36 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:18:36 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:18:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:18:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:18:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:18:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:18:36 --> Final output sent to browser
DEBUG - 2011-10-04 02:18:36 --> Total execution time: 2.1542
DEBUG - 2011-10-04 02:18:39 --> Config Class Initialized
DEBUG - 2011-10-04 02:18:39 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:18:39 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:18:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:18:39 --> URI Class Initialized
DEBUG - 2011-10-04 02:18:39 --> Router Class Initialized
ERROR - 2011-10-04 02:18:39 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-04 02:18:40 --> Config Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:18:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:18:40 --> URI Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Router Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Output Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Input Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:18:40 --> Language Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Loader Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Controller Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:18:40 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:18:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:18:40 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:18:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:18:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:18:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:18:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:18:40 --> Final output sent to browser
DEBUG - 2011-10-04 02:18:40 --> Total execution time: 0.0556
DEBUG - 2011-10-04 02:18:45 --> Config Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:18:45 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:18:45 --> URI Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Router Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Output Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Input Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:18:45 --> Language Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Loader Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Controller Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:18:45 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:18:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:18:46 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:18:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:18:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:18:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:18:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:18:46 --> Final output sent to browser
DEBUG - 2011-10-04 02:18:46 --> Total execution time: 1.4828
DEBUG - 2011-10-04 02:18:53 --> Config Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:18:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:18:53 --> URI Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Router Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Output Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Input Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:18:53 --> Language Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Loader Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Controller Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:18:53 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:18:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:18:54 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:18:54 --> Final output sent to browser
DEBUG - 2011-10-04 02:18:54 --> Total execution time: 0.4445
DEBUG - 2011-10-04 02:18:57 --> Config Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:18:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:18:57 --> URI Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Router Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Output Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Input Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:18:57 --> Language Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Loader Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Controller Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Model Class Initialized
DEBUG - 2011-10-04 02:18:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:18:57 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:18:57 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:18:57 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:18:57 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:18:57 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:18:57 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:18:57 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:18:57 --> Final output sent to browser
DEBUG - 2011-10-04 02:18:57 --> Total execution time: 0.0748
DEBUG - 2011-10-04 02:19:09 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:09 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:09 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:09 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:12 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:12 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:12 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:12 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:12 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:12 --> Total execution time: 0.3893
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:13 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:13 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:13 --> Total execution time: 4.0126
DEBUG - 2011-10-04 02:19:13 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:13 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:13 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:13 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:13 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:13 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:13 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:13 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:13 --> Total execution time: 0.0946
DEBUG - 2011-10-04 02:19:15 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:15 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:15 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:15 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:16 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:16 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:16 --> Total execution time: 0.0977
DEBUG - 2011-10-04 02:19:29 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:29 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:29 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:29 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:30 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:30 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:30 --> Total execution time: 0.3122
DEBUG - 2011-10-04 02:19:32 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:32 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:32 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:32 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:32 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:32 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:32 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:32 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:32 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:32 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:32 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:32 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:32 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:32 --> Total execution time: 0.1136
DEBUG - 2011-10-04 02:19:38 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:38 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:38 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:38 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:38 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:38 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:38 --> Total execution time: 0.3060
DEBUG - 2011-10-04 02:19:40 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:40 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:40 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:40 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:40 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:40 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:40 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:40 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:40 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:40 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:40 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:40 --> Total execution time: 0.0892
DEBUG - 2011-10-04 02:19:54 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:54 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:54 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:54 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:55 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:55 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:55 --> Total execution time: 1.0999
DEBUG - 2011-10-04 02:19:58 --> Config Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:19:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:19:58 --> URI Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Router Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Output Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Input Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:19:58 --> Language Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Loader Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Controller Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Model Class Initialized
DEBUG - 2011-10-04 02:19:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:19:58 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:19:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:19:58 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:19:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:19:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:19:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:19:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:19:58 --> Final output sent to browser
DEBUG - 2011-10-04 02:19:58 --> Total execution time: 0.0609
DEBUG - 2011-10-04 02:20:29 --> Config Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:20:29 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:20:29 --> URI Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Router Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Output Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Input Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:20:29 --> Language Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Loader Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Controller Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:20:29 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:20:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:20:30 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:20:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:20:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:20:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:20:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:20:30 --> Final output sent to browser
DEBUG - 2011-10-04 02:20:30 --> Total execution time: 1.0674
DEBUG - 2011-10-04 02:20:39 --> Config Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:20:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:20:39 --> URI Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Router Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Output Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Input Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:20:39 --> Language Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Loader Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Controller Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:20:39 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:20:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:20:39 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:20:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:20:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:20:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:20:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:20:39 --> Final output sent to browser
DEBUG - 2011-10-04 02:20:39 --> Total execution time: 0.0750
DEBUG - 2011-10-04 02:20:59 --> Config Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:20:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:20:59 --> URI Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Router Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Output Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Input Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:20:59 --> Language Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Loader Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Controller Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Model Class Initialized
DEBUG - 2011-10-04 02:20:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:20:59 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:21:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:21:00 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:21:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:21:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:21:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:21:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:21:00 --> Final output sent to browser
DEBUG - 2011-10-04 02:21:00 --> Total execution time: 0.4250
DEBUG - 2011-10-04 02:21:02 --> Config Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:21:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:21:02 --> URI Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Router Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Output Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Input Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:21:02 --> Language Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Loader Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Controller Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:21:02 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:21:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:21:02 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:21:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:21:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:21:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:21:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:21:02 --> Final output sent to browser
DEBUG - 2011-10-04 02:21:02 --> Total execution time: 0.0918
DEBUG - 2011-10-04 02:21:10 --> Config Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:21:10 --> URI Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Router Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Output Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Input Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:21:10 --> Language Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Loader Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Controller Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:21:10 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:21:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:21:11 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:21:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:21:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:21:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:21:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:21:11 --> Final output sent to browser
DEBUG - 2011-10-04 02:21:11 --> Total execution time: 1.0571
DEBUG - 2011-10-04 02:21:12 --> Config Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:21:12 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:21:12 --> URI Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Router Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Output Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Input Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:21:12 --> Language Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Loader Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Controller Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:21:12 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:21:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:21:12 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:21:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:21:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:21:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:21:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:21:12 --> Final output sent to browser
DEBUG - 2011-10-04 02:21:12 --> Total execution time: 0.1631
DEBUG - 2011-10-04 02:21:37 --> Config Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:21:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:21:37 --> URI Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Router Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Output Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Input Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:21:37 --> Language Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Loader Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Controller Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Model Class Initialized
DEBUG - 2011-10-04 02:21:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:21:37 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:21:41 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:21:41 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:21:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:21:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:21:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:21:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:21:41 --> Final output sent to browser
DEBUG - 2011-10-04 02:21:41 --> Total execution time: 3.7584
DEBUG - 2011-10-04 02:22:08 --> Config Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:22:08 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:22:08 --> URI Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Router Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Output Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Input Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:22:08 --> Language Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Loader Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Controller Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:08 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:22:08 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:22:08 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:22:08 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:22:08 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:22:08 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:22:08 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:22:08 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:22:08 --> Final output sent to browser
DEBUG - 2011-10-04 02:22:08 --> Total execution time: 0.1633
DEBUG - 2011-10-04 02:22:19 --> Config Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:22:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:22:19 --> URI Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Router Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Output Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Input Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:22:19 --> Language Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Loader Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Controller Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:22:19 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:22:20 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:22:20 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:22:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:22:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:22:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:22:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:22:20 --> Final output sent to browser
DEBUG - 2011-10-04 02:22:20 --> Total execution time: 0.7659
DEBUG - 2011-10-04 02:22:21 --> Config Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:22:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:22:21 --> URI Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Router Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Output Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Input Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:22:21 --> Language Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Loader Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Controller Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Model Class Initialized
DEBUG - 2011-10-04 02:22:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:22:21 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:22:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 02:22:22 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:22:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:22:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:22:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:22:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:22:22 --> Final output sent to browser
DEBUG - 2011-10-04 02:22:22 --> Total execution time: 0.0534
DEBUG - 2011-10-04 02:23:20 --> Config Class Initialized
DEBUG - 2011-10-04 02:23:20 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:23:20 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:23:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:23:20 --> URI Class Initialized
DEBUG - 2011-10-04 02:23:20 --> Router Class Initialized
DEBUG - 2011-10-04 02:23:20 --> No URI present. Default controller set.
DEBUG - 2011-10-04 02:23:20 --> Output Class Initialized
DEBUG - 2011-10-04 02:23:20 --> Input Class Initialized
DEBUG - 2011-10-04 02:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:23:20 --> Language Class Initialized
DEBUG - 2011-10-04 02:23:20 --> Loader Class Initialized
DEBUG - 2011-10-04 02:23:20 --> Controller Class Initialized
DEBUG - 2011-10-04 02:23:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-04 02:23:20 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:23:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:23:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:23:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:23:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:23:20 --> Final output sent to browser
DEBUG - 2011-10-04 02:23:20 --> Total execution time: 0.0804
DEBUG - 2011-10-04 02:23:36 --> Config Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:23:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:23:36 --> URI Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Router Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Output Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Input Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:23:36 --> Language Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Loader Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Controller Class Initialized
ERROR - 2011-10-04 02:23:36 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 02:23:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 02:23:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 02:23:36 --> Model Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Model Class Initialized
DEBUG - 2011-10-04 02:23:36 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:23:36 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:23:36 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 02:23:36 --> Helper loaded: url_helper
DEBUG - 2011-10-04 02:23:36 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 02:23:36 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 02:23:36 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 02:23:36 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 02:23:36 --> Final output sent to browser
DEBUG - 2011-10-04 02:23:36 --> Total execution time: 0.0914
DEBUG - 2011-10-04 02:23:37 --> Config Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Hooks Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Utf8 Class Initialized
DEBUG - 2011-10-04 02:23:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 02:23:37 --> URI Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Router Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Output Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Input Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 02:23:37 --> Language Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Loader Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Controller Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Model Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Model Class Initialized
DEBUG - 2011-10-04 02:23:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 02:23:37 --> Database Driver Class Initialized
DEBUG - 2011-10-04 02:23:38 --> Final output sent to browser
DEBUG - 2011-10-04 02:23:38 --> Total execution time: 0.8083
DEBUG - 2011-10-04 04:09:30 --> Config Class Initialized
DEBUG - 2011-10-04 04:09:30 --> Hooks Class Initialized
DEBUG - 2011-10-04 04:09:30 --> Utf8 Class Initialized
DEBUG - 2011-10-04 04:09:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 04:09:30 --> URI Class Initialized
DEBUG - 2011-10-04 04:09:30 --> Router Class Initialized
DEBUG - 2011-10-04 04:09:30 --> No URI present. Default controller set.
DEBUG - 2011-10-04 04:09:30 --> Output Class Initialized
DEBUG - 2011-10-04 04:09:30 --> Input Class Initialized
DEBUG - 2011-10-04 04:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 04:09:30 --> Language Class Initialized
DEBUG - 2011-10-04 04:09:30 --> Loader Class Initialized
DEBUG - 2011-10-04 04:09:30 --> Controller Class Initialized
DEBUG - 2011-10-04 04:09:30 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-04 04:09:30 --> Helper loaded: url_helper
DEBUG - 2011-10-04 04:09:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 04:09:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 04:09:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 04:09:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 04:09:30 --> Final output sent to browser
DEBUG - 2011-10-04 04:09:30 --> Total execution time: 0.1668
DEBUG - 2011-10-04 05:34:31 --> Config Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Hooks Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Utf8 Class Initialized
DEBUG - 2011-10-04 05:34:31 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 05:34:31 --> URI Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Router Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Output Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Input Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 05:34:31 --> Language Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Loader Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Controller Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Model Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Model Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Model Class Initialized
DEBUG - 2011-10-04 05:34:31 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 05:34:31 --> Database Driver Class Initialized
DEBUG - 2011-10-04 05:34:33 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 05:34:33 --> Helper loaded: url_helper
DEBUG - 2011-10-04 05:34:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 05:34:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 05:34:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 05:34:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 05:34:33 --> Final output sent to browser
DEBUG - 2011-10-04 05:34:33 --> Total execution time: 1.6573
DEBUG - 2011-10-04 05:34:36 --> Config Class Initialized
DEBUG - 2011-10-04 05:34:36 --> Hooks Class Initialized
DEBUG - 2011-10-04 05:34:36 --> Utf8 Class Initialized
DEBUG - 2011-10-04 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 05:34:36 --> URI Class Initialized
DEBUG - 2011-10-04 05:34:36 --> Router Class Initialized
ERROR - 2011-10-04 05:34:36 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 06:05:28 --> Config Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Hooks Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Utf8 Class Initialized
DEBUG - 2011-10-04 06:05:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 06:05:28 --> URI Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Router Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Output Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Input Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 06:05:28 --> Language Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Loader Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Controller Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Model Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Model Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Model Class Initialized
DEBUG - 2011-10-04 06:05:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 06:05:28 --> Database Driver Class Initialized
DEBUG - 2011-10-04 06:05:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 06:05:30 --> Helper loaded: url_helper
DEBUG - 2011-10-04 06:05:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 06:05:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 06:05:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 06:05:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 06:05:30 --> Final output sent to browser
DEBUG - 2011-10-04 06:05:30 --> Total execution time: 1.6277
DEBUG - 2011-10-04 07:14:13 --> Config Class Initialized
DEBUG - 2011-10-04 07:14:13 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:14:13 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:14:13 --> URI Class Initialized
DEBUG - 2011-10-04 07:14:13 --> Router Class Initialized
DEBUG - 2011-10-04 07:14:13 --> No URI present. Default controller set.
DEBUG - 2011-10-04 07:14:13 --> Output Class Initialized
DEBUG - 2011-10-04 07:14:13 --> Input Class Initialized
DEBUG - 2011-10-04 07:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:14:13 --> Language Class Initialized
DEBUG - 2011-10-04 07:14:13 --> Loader Class Initialized
DEBUG - 2011-10-04 07:14:13 --> Controller Class Initialized
DEBUG - 2011-10-04 07:14:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-04 07:14:14 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:14:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:14:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:14:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:14:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:14:14 --> Final output sent to browser
DEBUG - 2011-10-04 07:14:14 --> Total execution time: 0.2808
DEBUG - 2011-10-04 07:35:55 --> Config Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:35:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:35:55 --> URI Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Router Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Output Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Input Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:35:55 --> Language Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Loader Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Controller Class Initialized
ERROR - 2011-10-04 07:35:55 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 07:35:55 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 07:35:55 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 07:35:55 --> Model Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Model Class Initialized
DEBUG - 2011-10-04 07:35:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:35:55 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:35:56 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 07:35:56 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:35:56 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:35:56 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:35:56 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:35:56 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:35:56 --> Final output sent to browser
DEBUG - 2011-10-04 07:35:56 --> Total execution time: 0.5329
DEBUG - 2011-10-04 07:35:57 --> Config Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:35:57 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:35:57 --> URI Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Router Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Output Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Input Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:35:57 --> Language Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Loader Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Controller Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Model Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Model Class Initialized
DEBUG - 2011-10-04 07:35:57 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:35:57 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:35:58 --> Final output sent to browser
DEBUG - 2011-10-04 07:35:58 --> Total execution time: 0.9585
DEBUG - 2011-10-04 07:35:58 --> Config Class Initialized
DEBUG - 2011-10-04 07:35:58 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:35:58 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:35:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:35:58 --> URI Class Initialized
DEBUG - 2011-10-04 07:35:58 --> Router Class Initialized
ERROR - 2011-10-04 07:35:58 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 07:35:59 --> Config Class Initialized
DEBUG - 2011-10-04 07:35:59 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:35:59 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:35:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:35:59 --> URI Class Initialized
DEBUG - 2011-10-04 07:35:59 --> Router Class Initialized
ERROR - 2011-10-04 07:35:59 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 07:37:15 --> Config Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:37:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:37:15 --> URI Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Router Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Output Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Input Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:37:15 --> Language Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Loader Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Controller Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:37:15 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:37:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:37:16 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:37:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:37:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:37:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:37:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:37:16 --> Final output sent to browser
DEBUG - 2011-10-04 07:37:16 --> Total execution time: 0.6304
DEBUG - 2011-10-04 07:37:18 --> Config Class Initialized
DEBUG - 2011-10-04 07:37:18 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:37:18 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:37:18 --> URI Class Initialized
DEBUG - 2011-10-04 07:37:18 --> Router Class Initialized
ERROR - 2011-10-04 07:37:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 07:37:18 --> Config Class Initialized
DEBUG - 2011-10-04 07:37:18 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:37:18 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:37:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:37:18 --> URI Class Initialized
DEBUG - 2011-10-04 07:37:18 --> Router Class Initialized
ERROR - 2011-10-04 07:37:18 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 07:37:42 --> Config Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:37:42 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:37:42 --> URI Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Router Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Output Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Input Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:37:42 --> Language Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Loader Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Controller Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:42 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:37:42 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:37:43 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:37:43 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:37:43 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:37:43 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:37:43 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:37:43 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:37:43 --> Final output sent to browser
DEBUG - 2011-10-04 07:37:43 --> Total execution time: 1.2745
DEBUG - 2011-10-04 07:37:46 --> Config Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:37:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:37:46 --> URI Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Router Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Output Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Input Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:37:46 --> Language Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Loader Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Controller Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:37:46 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:37:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:37:46 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:37:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:37:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:37:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:37:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:37:46 --> Final output sent to browser
DEBUG - 2011-10-04 07:37:46 --> Total execution time: 0.1381
DEBUG - 2011-10-04 07:37:59 --> Config Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:37:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:37:59 --> URI Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Router Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Output Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Input Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:37:59 --> Language Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Loader Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Controller Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:37:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:38:00 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:38:00 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:38:00 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:38:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:38:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:38:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:38:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:38:00 --> Final output sent to browser
DEBUG - 2011-10-04 07:38:00 --> Total execution time: 0.7382
DEBUG - 2011-10-04 07:38:05 --> Config Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:38:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:38:05 --> URI Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Router Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Output Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Input Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:38:05 --> Language Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Loader Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Controller Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:38:05 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:38:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:38:05 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:38:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:38:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:38:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:38:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:38:05 --> Final output sent to browser
DEBUG - 2011-10-04 07:38:05 --> Total execution time: 0.0573
DEBUG - 2011-10-04 07:38:19 --> Config Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:38:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:38:19 --> URI Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Router Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Output Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Input Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:38:19 --> Language Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Loader Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Controller Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:38:19 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:38:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:38:19 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:38:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:38:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:38:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:38:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:38:19 --> Final output sent to browser
DEBUG - 2011-10-04 07:38:19 --> Total execution time: 0.3792
DEBUG - 2011-10-04 07:38:28 --> Config Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:38:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:38:28 --> URI Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Router Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Output Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Input Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:38:28 --> Language Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Loader Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Controller Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:38:28 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:38:29 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:38:29 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:38:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:38:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:38:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:38:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:38:29 --> Final output sent to browser
DEBUG - 2011-10-04 07:38:29 --> Total execution time: 0.5289
DEBUG - 2011-10-04 07:38:47 --> Config Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:38:47 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:38:47 --> URI Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Router Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Output Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Input Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:38:47 --> Language Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Loader Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Controller Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Model Class Initialized
DEBUG - 2011-10-04 07:38:47 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:38:47 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:38:47 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:38:47 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:38:47 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:38:47 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:38:47 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:38:47 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:38:47 --> Final output sent to browser
DEBUG - 2011-10-04 07:38:47 --> Total execution time: 0.2711
DEBUG - 2011-10-04 07:39:00 --> Config Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:39:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:39:00 --> URI Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Router Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Output Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Input Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:39:00 --> Language Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Loader Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Controller Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:39:00 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:39:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:39:01 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:39:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:39:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:39:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:39:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:39:01 --> Final output sent to browser
DEBUG - 2011-10-04 07:39:01 --> Total execution time: 0.4616
DEBUG - 2011-10-04 07:39:09 --> Config Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:39:09 --> URI Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Router Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Output Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Input Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:39:09 --> Language Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Loader Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Controller Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:39:09 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:39:09 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:39:09 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:39:09 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:39:09 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:39:09 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:39:09 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:39:09 --> Final output sent to browser
DEBUG - 2011-10-04 07:39:09 --> Total execution time: 0.3231
DEBUG - 2011-10-04 07:39:19 --> Config Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:39:19 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:39:19 --> URI Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Router Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Output Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Input Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:39:19 --> Language Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Loader Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Controller Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:19 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:39:19 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:39:19 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:39:19 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:39:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:39:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:39:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:39:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:39:19 --> Final output sent to browser
DEBUG - 2011-10-04 07:39:19 --> Total execution time: 0.4980
DEBUG - 2011-10-04 07:39:30 --> Config Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:39:30 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:39:30 --> URI Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Router Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Output Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Input Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:39:30 --> Language Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Loader Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Controller Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:39:30 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:39:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:39:30 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:39:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:39:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:39:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:39:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:39:30 --> Final output sent to browser
DEBUG - 2011-10-04 07:39:30 --> Total execution time: 0.3672
DEBUG - 2011-10-04 07:39:38 --> Config Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:39:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:39:38 --> URI Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Router Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Output Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Input Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:39:38 --> Language Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Loader Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Controller Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:39:38 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:39:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:39:39 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:39:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:39:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:39:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:39:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:39:39 --> Final output sent to browser
DEBUG - 2011-10-04 07:39:39 --> Total execution time: 0.5899
DEBUG - 2011-10-04 07:39:46 --> Config Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:39:46 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:39:46 --> URI Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Router Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Output Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Input Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:39:46 --> Language Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Loader Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Controller Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:46 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:39:46 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:39:46 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:39:46 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:39:46 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:39:46 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:39:46 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:39:46 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:39:46 --> Final output sent to browser
DEBUG - 2011-10-04 07:39:46 --> Total execution time: 0.1509
DEBUG - 2011-10-04 07:39:55 --> Config Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:39:55 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:39:55 --> URI Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Router Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Output Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Input Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:39:55 --> Language Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Loader Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Controller Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Model Class Initialized
DEBUG - 2011-10-04 07:39:55 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:39:55 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:39:55 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:39:55 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:39:55 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:39:55 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:39:55 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:39:55 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:39:55 --> Final output sent to browser
DEBUG - 2011-10-04 07:39:55 --> Total execution time: 0.2778
DEBUG - 2011-10-04 07:40:05 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:05 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:05 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:05 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:05 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:05 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:05 --> Total execution time: 0.4516
DEBUG - 2011-10-04 07:40:14 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:14 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:14 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:14 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:15 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:15 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:15 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:15 --> Total execution time: 1.2938
DEBUG - 2011-10-04 07:40:24 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:24 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:24 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:24 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:24 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:24 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:24 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:24 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:24 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:24 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:24 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:24 --> Total execution time: 0.3260
DEBUG - 2011-10-04 07:40:37 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:37 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:37 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:37 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:37 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:37 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:37 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:37 --> Total execution time: 0.0510
DEBUG - 2011-10-04 07:40:37 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:37 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:37 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:38 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:38 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:38 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:38 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:38 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:38 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:38 --> Total execution time: 0.3813
DEBUG - 2011-10-04 07:40:39 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:39 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:39 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:39 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:39 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:39 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:39 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:39 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:39 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:39 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:39 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:39 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:39 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:39 --> Total execution time: 0.0494
DEBUG - 2011-10-04 07:40:48 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:48 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:48 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:48 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:48 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:49 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:49 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:49 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:49 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:49 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:49 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:49 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:49 --> Total execution time: 0.7993
DEBUG - 2011-10-04 07:40:58 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:58 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:58 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:58 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:58 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:58 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:58 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:58 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:58 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:58 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:58 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:58 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:58 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:58 --> Total execution time: 0.0491
DEBUG - 2011-10-04 07:40:59 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:59 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:59 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:59 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:59 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:59 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:59 --> Total execution time: 0.0489
DEBUG - 2011-10-04 07:40:59 --> Config Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:40:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:40:59 --> URI Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Router Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Output Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Input Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:40:59 --> Language Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Loader Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Controller Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Model Class Initialized
DEBUG - 2011-10-04 07:40:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:40:59 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:40:59 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:40:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:40:59 --> Final output sent to browser
DEBUG - 2011-10-04 07:40:59 --> Total execution time: 0.0585
DEBUG - 2011-10-04 07:41:01 --> Config Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:41:01 --> URI Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Router Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Output Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Input Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:41:01 --> Language Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Loader Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Controller Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:41:01 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:41:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:41:01 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:41:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:41:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:41:01 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:41:01 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:41:01 --> Final output sent to browser
DEBUG - 2011-10-04 07:41:01 --> Total execution time: 0.0825
DEBUG - 2011-10-04 07:41:01 --> Config Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:41:01 --> URI Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Router Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Output Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Input Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:41:01 --> Language Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Loader Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Controller Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:01 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:41:01 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:41:01 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:41:01 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:41:01 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:41:01 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:41:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:41:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:41:02 --> Final output sent to browser
DEBUG - 2011-10-04 07:41:02 --> Total execution time: 0.1233
DEBUG - 2011-10-04 07:41:04 --> Config Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:41:04 --> URI Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Router Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Output Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Input Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:41:04 --> Language Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Loader Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Controller Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:41:04 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:41:04 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:41:04 --> Final output sent to browser
DEBUG - 2011-10-04 07:41:04 --> Total execution time: 0.0714
DEBUG - 2011-10-04 07:41:04 --> Config Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:41:04 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:41:04 --> URI Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Router Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Output Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Input Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:41:04 --> Language Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Loader Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Controller Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:04 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:41:04 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:41:04 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:41:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:41:04 --> Final output sent to browser
DEBUG - 2011-10-04 07:41:04 --> Total execution time: 0.0893
DEBUG - 2011-10-04 07:41:06 --> Config Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:41:06 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:41:06 --> URI Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Router Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Output Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Input Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:41:06 --> Language Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Loader Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Controller Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:06 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:41:06 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:41:06 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:41:06 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:41:06 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:41:06 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:41:06 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:41:06 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:41:06 --> Final output sent to browser
DEBUG - 2011-10-04 07:41:06 --> Total execution time: 0.0792
DEBUG - 2011-10-04 07:41:11 --> Config Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:41:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:41:11 --> URI Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Router Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Output Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Input Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:41:11 --> Language Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Loader Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Controller Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:41:11 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:41:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:41:11 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:41:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:41:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:41:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:41:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:41:11 --> Final output sent to browser
DEBUG - 2011-10-04 07:41:11 --> Total execution time: 0.0730
DEBUG - 2011-10-04 07:41:14 --> Config Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:41:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:41:14 --> URI Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Router Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Output Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Input Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:41:14 --> Language Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Loader Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Controller Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:41:14 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:41:14 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:41:14 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:41:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:41:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:41:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:41:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:41:14 --> Final output sent to browser
DEBUG - 2011-10-04 07:41:14 --> Total execution time: 0.0582
DEBUG - 2011-10-04 07:41:15 --> Config Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Hooks Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Utf8 Class Initialized
DEBUG - 2011-10-04 07:41:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 07:41:15 --> URI Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Router Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Output Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Input Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 07:41:15 --> Language Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Loader Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Controller Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Model Class Initialized
DEBUG - 2011-10-04 07:41:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 07:41:15 --> Database Driver Class Initialized
DEBUG - 2011-10-04 07:41:16 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 07:41:16 --> Helper loaded: url_helper
DEBUG - 2011-10-04 07:41:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 07:41:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 07:41:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 07:41:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 07:41:16 --> Final output sent to browser
DEBUG - 2011-10-04 07:41:16 --> Total execution time: 0.0669
DEBUG - 2011-10-04 08:20:43 --> Config Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:20:43 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:20:43 --> URI Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Router Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Output Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Input Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:20:43 --> Language Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Loader Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Controller Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Model Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Model Class Initialized
DEBUG - 2011-10-04 08:20:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:20:43 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:20:44 --> Final output sent to browser
DEBUG - 2011-10-04 08:20:44 --> Total execution time: 0.9020
DEBUG - 2011-10-04 08:24:18 --> Config Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:24:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:24:18 --> URI Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Router Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Output Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Input Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:24:18 --> Language Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Loader Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Controller Class Initialized
ERROR - 2011-10-04 08:24:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:24:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:24:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:24:18 --> Model Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Model Class Initialized
DEBUG - 2011-10-04 08:24:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:24:18 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:24:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:24:18 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:24:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:24:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:24:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:24:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:24:18 --> Final output sent to browser
DEBUG - 2011-10-04 08:24:18 --> Total execution time: 0.4848
DEBUG - 2011-10-04 08:24:23 --> Config Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:24:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:24:23 --> URI Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Router Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Output Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Input Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:24:23 --> Language Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Loader Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Controller Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Model Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Model Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:24:23 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:24:23 --> Final output sent to browser
DEBUG - 2011-10-04 08:24:23 --> Total execution time: 0.6241
DEBUG - 2011-10-04 08:25:14 --> Config Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:25:14 --> URI Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Router Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Output Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Input Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:25:14 --> Language Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Loader Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Controller Class Initialized
ERROR - 2011-10-04 08:25:14 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:25:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:25:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:25:14 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:14 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:25:14 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:25:14 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:25:14 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:25:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:25:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:25:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:25:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:25:15 --> Final output sent to browser
DEBUG - 2011-10-04 08:25:15 --> Total execution time: 0.0355
DEBUG - 2011-10-04 08:25:16 --> Config Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:25:16 --> URI Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Router Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Output Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Input Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:25:16 --> Language Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Loader Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Controller Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:16 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:25:16 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:25:17 --> Final output sent to browser
DEBUG - 2011-10-04 08:25:17 --> Total execution time: 0.8387
DEBUG - 2011-10-04 08:25:22 --> Config Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:25:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:25:22 --> URI Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Router Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Output Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Input Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:25:22 --> Language Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Loader Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Controller Class Initialized
ERROR - 2011-10-04 08:25:22 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:25:22 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:25:22 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:25:22 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:25:22 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:25:22 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:25:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:25:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:25:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:25:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:25:22 --> Final output sent to browser
DEBUG - 2011-10-04 08:25:22 --> Total execution time: 0.0435
DEBUG - 2011-10-04 08:25:24 --> Config Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:25:24 --> URI Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Router Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Output Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Input Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:25:24 --> Language Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Loader Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Controller Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:24 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:25:24 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:25:25 --> Final output sent to browser
DEBUG - 2011-10-04 08:25:25 --> Total execution time: 0.6195
DEBUG - 2011-10-04 08:25:38 --> Config Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:25:38 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:25:38 --> URI Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Router Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Output Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Input Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:25:38 --> Language Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Loader Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Controller Class Initialized
ERROR - 2011-10-04 08:25:38 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:25:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:25:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:25:38 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:38 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:25:38 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:25:38 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:25:38 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:25:38 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:25:38 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:25:38 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:25:38 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:25:38 --> Final output sent to browser
DEBUG - 2011-10-04 08:25:38 --> Total execution time: 0.0336
DEBUG - 2011-10-04 08:25:40 --> Config Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:25:40 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:25:40 --> URI Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Router Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Output Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Input Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:25:40 --> Language Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Loader Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Controller Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:40 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:25:40 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:25:41 --> Final output sent to browser
DEBUG - 2011-10-04 08:25:41 --> Total execution time: 0.5632
DEBUG - 2011-10-04 08:25:54 --> Config Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:25:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:25:54 --> URI Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Router Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Output Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Input Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:25:54 --> Language Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Loader Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Controller Class Initialized
ERROR - 2011-10-04 08:25:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:25:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:25:54 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:25:54 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:25:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:25:54 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:25:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:25:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:25:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:25:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:25:54 --> Final output sent to browser
DEBUG - 2011-10-04 08:25:54 --> Total execution time: 0.0358
DEBUG - 2011-10-04 08:25:56 --> Config Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:25:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:25:56 --> URI Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Router Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Output Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Input Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:25:56 --> Language Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Loader Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Controller Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Model Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:25:56 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:25:56 --> Final output sent to browser
DEBUG - 2011-10-04 08:25:56 --> Total execution time: 0.5868
DEBUG - 2011-10-04 08:26:05 --> Config Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:26:05 --> URI Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Router Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Output Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Input Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:26:05 --> Language Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Loader Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Controller Class Initialized
ERROR - 2011-10-04 08:26:05 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:26:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:26:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:26:05 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:26:05 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:26:05 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:26:05 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:26:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:26:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:26:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:26:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:26:05 --> Final output sent to browser
DEBUG - 2011-10-04 08:26:05 --> Total execution time: 0.0486
DEBUG - 2011-10-04 08:26:07 --> Config Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:26:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:26:07 --> URI Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Router Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Output Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Input Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:26:07 --> Language Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Loader Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Controller Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:26:07 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:26:07 --> Final output sent to browser
DEBUG - 2011-10-04 08:26:07 --> Total execution time: 0.5369
DEBUG - 2011-10-04 08:26:33 --> Config Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:26:33 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:26:33 --> URI Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Router Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Output Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Input Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:26:33 --> Language Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Loader Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Controller Class Initialized
ERROR - 2011-10-04 08:26:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:26:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:26:33 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:26:33 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:26:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:26:33 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:26:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:26:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:26:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:26:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:26:33 --> Final output sent to browser
DEBUG - 2011-10-04 08:26:33 --> Total execution time: 0.0305
DEBUG - 2011-10-04 08:26:35 --> Config Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:26:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:26:35 --> URI Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Router Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Output Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Input Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:26:35 --> Language Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Loader Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Controller Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:26:35 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:26:35 --> Final output sent to browser
DEBUG - 2011-10-04 08:26:35 --> Total execution time: 0.6874
DEBUG - 2011-10-04 08:26:51 --> Config Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:26:51 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:26:51 --> URI Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Router Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Output Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Input Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:26:51 --> Language Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Loader Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Controller Class Initialized
ERROR - 2011-10-04 08:26:51 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:26:51 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:26:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:26:51 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:26:51 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:26:51 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:26:51 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:26:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:26:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:26:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:26:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:26:51 --> Final output sent to browser
DEBUG - 2011-10-04 08:26:51 --> Total execution time: 0.0493
DEBUG - 2011-10-04 08:26:53 --> Config Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:26:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:26:53 --> URI Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Router Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Output Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Input Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:26:53 --> Language Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Loader Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Controller Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Model Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:26:53 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:26:53 --> Final output sent to browser
DEBUG - 2011-10-04 08:26:53 --> Total execution time: 0.6453
DEBUG - 2011-10-04 08:27:00 --> Config Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:27:00 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:27:00 --> URI Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Router Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Output Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Input Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:27:00 --> Language Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Loader Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Controller Class Initialized
ERROR - 2011-10-04 08:27:00 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 08:27:00 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 08:27:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:27:00 --> Model Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Model Class Initialized
DEBUG - 2011-10-04 08:27:00 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:27:00 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:27:00 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 08:27:00 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:27:00 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:27:00 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:27:00 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:27:00 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:27:00 --> Final output sent to browser
DEBUG - 2011-10-04 08:27:00 --> Total execution time: 0.0391
DEBUG - 2011-10-04 08:27:02 --> Config Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:27:02 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:27:02 --> URI Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Router Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Output Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Input Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:27:02 --> Language Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Loader Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Controller Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Model Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Model Class Initialized
DEBUG - 2011-10-04 08:27:02 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:27:02 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:27:03 --> Final output sent to browser
DEBUG - 2011-10-04 08:27:03 --> Total execution time: 0.7136
DEBUG - 2011-10-04 08:34:34 --> Config Class Initialized
DEBUG - 2011-10-04 08:34:34 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:34:34 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:34:34 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:34:34 --> URI Class Initialized
DEBUG - 2011-10-04 08:34:34 --> Router Class Initialized
ERROR - 2011-10-04 08:34:34 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-04 08:34:35 --> Config Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Hooks Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Utf8 Class Initialized
DEBUG - 2011-10-04 08:34:35 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 08:34:35 --> URI Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Router Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Output Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Input Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 08:34:35 --> Language Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Loader Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Controller Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Model Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Model Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Model Class Initialized
DEBUG - 2011-10-04 08:34:35 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 08:34:35 --> Database Driver Class Initialized
DEBUG - 2011-10-04 08:34:35 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 08:34:35 --> Helper loaded: url_helper
DEBUG - 2011-10-04 08:34:35 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 08:34:35 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 08:34:35 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 08:34:35 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 08:34:35 --> Final output sent to browser
DEBUG - 2011-10-04 08:34:35 --> Total execution time: 0.5413
DEBUG - 2011-10-04 10:01:50 --> Config Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:01:50 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:01:50 --> URI Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Router Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Output Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Input Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 10:01:50 --> Language Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Loader Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Controller Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Model Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Model Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Model Class Initialized
DEBUG - 2011-10-04 10:01:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 10:01:50 --> Database Driver Class Initialized
DEBUG - 2011-10-04 10:01:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 10:01:52 --> Helper loaded: url_helper
DEBUG - 2011-10-04 10:01:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 10:01:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 10:01:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 10:01:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 10:01:52 --> Final output sent to browser
DEBUG - 2011-10-04 10:01:52 --> Total execution time: 1.5206
DEBUG - 2011-10-04 10:01:56 --> Config Class Initialized
DEBUG - 2011-10-04 10:01:56 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:01:56 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:01:56 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:01:56 --> URI Class Initialized
DEBUG - 2011-10-04 10:01:56 --> Router Class Initialized
ERROR - 2011-10-04 10:01:56 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 10:38:11 --> Config Class Initialized
DEBUG - 2011-10-04 10:38:11 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:38:11 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:38:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:38:11 --> URI Class Initialized
DEBUG - 2011-10-04 10:38:11 --> Router Class Initialized
ERROR - 2011-10-04 10:38:11 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-04 10:40:09 --> Config Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:40:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:40:09 --> URI Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Router Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Output Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Input Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 10:40:09 --> Language Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Loader Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Controller Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Model Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Model Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Model Class Initialized
DEBUG - 2011-10-04 10:40:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 10:40:09 --> Database Driver Class Initialized
DEBUG - 2011-10-04 10:40:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 10:40:10 --> Helper loaded: url_helper
DEBUG - 2011-10-04 10:40:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 10:40:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 10:40:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 10:40:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 10:40:10 --> Final output sent to browser
DEBUG - 2011-10-04 10:40:10 --> Total execution time: 1.0366
DEBUG - 2011-10-04 10:55:22 --> Config Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:55:22 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:55:22 --> URI Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Router Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Output Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Input Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 10:55:22 --> Language Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Loader Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Controller Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 10:55:22 --> Database Driver Class Initialized
DEBUG - 2011-10-04 10:55:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 10:55:22 --> Helper loaded: url_helper
DEBUG - 2011-10-04 10:55:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 10:55:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 10:55:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 10:55:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 10:55:22 --> Final output sent to browser
DEBUG - 2011-10-04 10:55:22 --> Total execution time: 0.0478
DEBUG - 2011-10-04 10:55:24 --> Config Class Initialized
DEBUG - 2011-10-04 10:55:24 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:55:24 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:55:24 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:55:24 --> URI Class Initialized
DEBUG - 2011-10-04 10:55:24 --> Router Class Initialized
ERROR - 2011-10-04 10:55:24 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 10:55:52 --> Config Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:55:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:55:52 --> URI Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Router Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Output Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Input Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 10:55:52 --> Language Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Loader Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Controller Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 10:55:52 --> Database Driver Class Initialized
DEBUG - 2011-10-04 10:55:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 10:55:52 --> Helper loaded: url_helper
DEBUG - 2011-10-04 10:55:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 10:55:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 10:55:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 10:55:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 10:55:52 --> Final output sent to browser
DEBUG - 2011-10-04 10:55:52 --> Total execution time: 0.2690
DEBUG - 2011-10-04 10:55:53 --> Config Class Initialized
DEBUG - 2011-10-04 10:55:53 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:55:53 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:55:53 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:55:53 --> URI Class Initialized
DEBUG - 2011-10-04 10:55:53 --> Router Class Initialized
ERROR - 2011-10-04 10:55:53 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 10:55:54 --> Config Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Hooks Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Utf8 Class Initialized
DEBUG - 2011-10-04 10:55:54 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 10:55:54 --> URI Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Router Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Output Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Input Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 10:55:54 --> Language Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Loader Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Controller Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Model Class Initialized
DEBUG - 2011-10-04 10:55:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 10:55:54 --> Database Driver Class Initialized
DEBUG - 2011-10-04 10:55:54 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 10:55:54 --> Helper loaded: url_helper
DEBUG - 2011-10-04 10:55:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 10:55:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 10:55:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 10:55:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 10:55:54 --> Final output sent to browser
DEBUG - 2011-10-04 10:55:54 --> Total execution time: 0.0497
DEBUG - 2011-10-04 11:08:20 --> Config Class Initialized
DEBUG - 2011-10-04 11:08:20 --> Hooks Class Initialized
DEBUG - 2011-10-04 11:08:20 --> Utf8 Class Initialized
DEBUG - 2011-10-04 11:08:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 11:08:20 --> URI Class Initialized
DEBUG - 2011-10-04 11:08:20 --> Router Class Initialized
DEBUG - 2011-10-04 11:08:20 --> No URI present. Default controller set.
DEBUG - 2011-10-04 11:08:20 --> Output Class Initialized
DEBUG - 2011-10-04 11:08:20 --> Input Class Initialized
DEBUG - 2011-10-04 11:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 11:08:20 --> Language Class Initialized
DEBUG - 2011-10-04 11:08:20 --> Loader Class Initialized
DEBUG - 2011-10-04 11:08:20 --> Controller Class Initialized
DEBUG - 2011-10-04 11:08:20 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-04 11:08:20 --> Helper loaded: url_helper
DEBUG - 2011-10-04 11:08:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 11:08:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 11:08:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 11:08:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 11:08:20 --> Final output sent to browser
DEBUG - 2011-10-04 11:08:20 --> Total execution time: 0.0622
DEBUG - 2011-10-04 11:49:58 --> Config Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Hooks Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Utf8 Class Initialized
DEBUG - 2011-10-04 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 11:49:59 --> URI Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Router Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Output Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Input Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 11:49:59 --> Language Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Loader Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Controller Class Initialized
ERROR - 2011-10-04 11:49:59 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 11:49:59 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 11:49:59 --> Model Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Model Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 11:49:59 --> Config Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Hooks Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Utf8 Class Initialized
DEBUG - 2011-10-04 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 11:49:59 --> Database Driver Class Initialized
DEBUG - 2011-10-04 11:49:59 --> URI Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Router Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Output Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Input Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 11:49:59 --> Language Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Loader Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Controller Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Model Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Model Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Model Class Initialized
DEBUG - 2011-10-04 11:49:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 11:49:59 --> Database Driver Class Initialized
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 11:49:59 --> Helper loaded: url_helper
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 11:49:59 --> Final output sent to browser
DEBUG - 2011-10-04 11:49:59 --> Total execution time: 0.6426
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 11:49:59 --> Helper loaded: url_helper
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 11:49:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 11:49:59 --> Final output sent to browser
DEBUG - 2011-10-04 11:49:59 --> Total execution time: 0.8512
DEBUG - 2011-10-04 12:32:25 --> Config Class Initialized
DEBUG - 2011-10-04 12:32:25 --> Hooks Class Initialized
DEBUG - 2011-10-04 12:32:25 --> Utf8 Class Initialized
DEBUG - 2011-10-04 12:32:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 12:32:25 --> URI Class Initialized
DEBUG - 2011-10-04 12:32:25 --> Router Class Initialized
DEBUG - 2011-10-04 12:32:25 --> Output Class Initialized
DEBUG - 2011-10-04 12:32:25 --> Input Class Initialized
DEBUG - 2011-10-04 12:32:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 12:32:26 --> Language Class Initialized
DEBUG - 2011-10-04 12:32:26 --> Loader Class Initialized
DEBUG - 2011-10-04 12:32:26 --> Controller Class Initialized
ERROR - 2011-10-04 12:32:26 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 12:32:26 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 12:32:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 12:32:26 --> Model Class Initialized
DEBUG - 2011-10-04 12:32:26 --> Model Class Initialized
DEBUG - 2011-10-04 12:32:26 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 12:32:26 --> Database Driver Class Initialized
DEBUG - 2011-10-04 12:32:26 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 12:32:26 --> Helper loaded: url_helper
DEBUG - 2011-10-04 12:32:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 12:32:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 12:32:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 12:32:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 12:32:26 --> Final output sent to browser
DEBUG - 2011-10-04 12:32:26 --> Total execution time: 0.2211
DEBUG - 2011-10-04 13:39:18 --> Config Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Hooks Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Utf8 Class Initialized
DEBUG - 2011-10-04 13:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 13:39:18 --> URI Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Router Class Initialized
ERROR - 2011-10-04 13:39:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-04 13:39:18 --> Config Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Hooks Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Utf8 Class Initialized
DEBUG - 2011-10-04 13:39:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 13:39:18 --> URI Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Router Class Initialized
DEBUG - 2011-10-04 13:39:18 --> No URI present. Default controller set.
DEBUG - 2011-10-04 13:39:18 --> Output Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Input Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 13:39:18 --> Language Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Loader Class Initialized
DEBUG - 2011-10-04 13:39:18 --> Controller Class Initialized
DEBUG - 2011-10-04 13:39:18 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-04 13:39:18 --> Helper loaded: url_helper
DEBUG - 2011-10-04 13:39:18 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 13:39:18 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 13:39:18 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 13:39:18 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 13:39:18 --> Final output sent to browser
DEBUG - 2011-10-04 13:39:18 --> Total execution time: 0.0814
DEBUG - 2011-10-04 13:47:09 --> Config Class Initialized
DEBUG - 2011-10-04 13:47:09 --> Hooks Class Initialized
DEBUG - 2011-10-04 13:47:09 --> Utf8 Class Initialized
DEBUG - 2011-10-04 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 13:47:09 --> URI Class Initialized
DEBUG - 2011-10-04 13:47:09 --> Router Class Initialized
ERROR - 2011-10-04 13:47:09 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-04 13:47:11 --> Config Class Initialized
DEBUG - 2011-10-04 13:47:11 --> Hooks Class Initialized
DEBUG - 2011-10-04 13:47:11 --> Utf8 Class Initialized
DEBUG - 2011-10-04 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 13:47:11 --> URI Class Initialized
DEBUG - 2011-10-04 13:47:11 --> Router Class Initialized
DEBUG - 2011-10-04 13:47:11 --> No URI present. Default controller set.
DEBUG - 2011-10-04 13:47:11 --> Output Class Initialized
DEBUG - 2011-10-04 13:47:11 --> Input Class Initialized
DEBUG - 2011-10-04 13:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 13:47:11 --> Language Class Initialized
DEBUG - 2011-10-04 13:47:11 --> Loader Class Initialized
DEBUG - 2011-10-04 13:47:11 --> Controller Class Initialized
DEBUG - 2011-10-04 13:47:11 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-04 13:47:11 --> Helper loaded: url_helper
DEBUG - 2011-10-04 13:47:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 13:47:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 13:47:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 13:47:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 13:47:11 --> Final output sent to browser
DEBUG - 2011-10-04 13:47:11 --> Total execution time: 0.0331
DEBUG - 2011-10-04 14:45:21 --> Config Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Hooks Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Utf8 Class Initialized
DEBUG - 2011-10-04 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 14:45:21 --> URI Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Router Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Output Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Input Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 14:45:21 --> Language Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Loader Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Controller Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Model Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Model Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Model Class Initialized
DEBUG - 2011-10-04 14:45:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 14:45:21 --> Database Driver Class Initialized
DEBUG - 2011-10-04 14:45:22 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 14:45:22 --> Helper loaded: url_helper
DEBUG - 2011-10-04 14:45:22 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 14:45:22 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 14:45:22 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 14:45:22 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 14:45:22 --> Final output sent to browser
DEBUG - 2011-10-04 14:45:22 --> Total execution time: 1.0665
DEBUG - 2011-10-04 14:45:25 --> Config Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Hooks Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Utf8 Class Initialized
DEBUG - 2011-10-04 14:45:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 14:45:25 --> URI Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Router Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Output Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Input Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 14:45:25 --> Language Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Loader Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Controller Class Initialized
ERROR - 2011-10-04 14:45:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 14:45:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 14:45:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 14:45:25 --> Model Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Model Class Initialized
DEBUG - 2011-10-04 14:45:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 14:45:25 --> Database Driver Class Initialized
DEBUG - 2011-10-04 14:45:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 14:45:25 --> Helper loaded: url_helper
DEBUG - 2011-10-04 14:45:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 14:45:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 14:45:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 14:45:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 14:45:25 --> Final output sent to browser
DEBUG - 2011-10-04 14:45:25 --> Total execution time: 0.0534
DEBUG - 2011-10-04 14:46:15 --> Config Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Hooks Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Utf8 Class Initialized
DEBUG - 2011-10-04 14:46:15 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 14:46:15 --> URI Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Router Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Output Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Input Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 14:46:15 --> Language Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Loader Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Controller Class Initialized
ERROR - 2011-10-04 14:46:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 14:46:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 14:46:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 14:46:15 --> Model Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Model Class Initialized
DEBUG - 2011-10-04 14:46:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 14:46:15 --> Database Driver Class Initialized
DEBUG - 2011-10-04 14:46:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 14:46:15 --> Helper loaded: url_helper
DEBUG - 2011-10-04 14:46:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 14:46:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 14:46:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 14:46:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 14:46:15 --> Final output sent to browser
DEBUG - 2011-10-04 14:46:15 --> Total execution time: 0.0353
DEBUG - 2011-10-04 14:46:25 --> Config Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Hooks Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Utf8 Class Initialized
DEBUG - 2011-10-04 14:46:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 14:46:25 --> URI Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Router Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Output Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Input Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 14:46:25 --> Language Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Loader Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Controller Class Initialized
ERROR - 2011-10-04 14:46:25 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 14:46:25 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 14:46:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 14:46:25 --> Model Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Model Class Initialized
DEBUG - 2011-10-04 14:46:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 14:46:25 --> Database Driver Class Initialized
DEBUG - 2011-10-04 14:46:25 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 14:46:25 --> Helper loaded: url_helper
DEBUG - 2011-10-04 14:46:25 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 14:46:25 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 14:46:25 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 14:46:25 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 14:46:25 --> Final output sent to browser
DEBUG - 2011-10-04 14:46:25 --> Total execution time: 0.1041
DEBUG - 2011-10-04 15:37:25 --> Config Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Hooks Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Utf8 Class Initialized
DEBUG - 2011-10-04 15:37:25 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 15:37:25 --> URI Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Router Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Output Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Input Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 15:37:25 --> Language Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Loader Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Controller Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Model Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Model Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Model Class Initialized
DEBUG - 2011-10-04 15:37:25 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 15:37:25 --> Database Driver Class Initialized
DEBUG - 2011-10-04 15:37:26 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 15:37:26 --> Helper loaded: url_helper
DEBUG - 2011-10-04 15:37:26 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 15:37:26 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 15:37:26 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 15:37:26 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 15:37:26 --> Final output sent to browser
DEBUG - 2011-10-04 15:37:26 --> Total execution time: 0.4913
DEBUG - 2011-10-04 15:37:27 --> Config Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Hooks Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Utf8 Class Initialized
DEBUG - 2011-10-04 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 15:37:27 --> URI Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Router Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Output Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Input Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 15:37:27 --> Language Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Loader Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Controller Class Initialized
ERROR - 2011-10-04 15:37:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 15:37:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 15:37:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 15:37:27 --> Model Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Model Class Initialized
DEBUG - 2011-10-04 15:37:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 15:37:27 --> Database Driver Class Initialized
DEBUG - 2011-10-04 15:37:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 15:37:27 --> Helper loaded: url_helper
DEBUG - 2011-10-04 15:37:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 15:37:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 15:37:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 15:37:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 15:37:27 --> Final output sent to browser
DEBUG - 2011-10-04 15:37:27 --> Total execution time: 0.0295
DEBUG - 2011-10-04 16:44:28 --> Config Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Hooks Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Utf8 Class Initialized
DEBUG - 2011-10-04 16:44:28 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 16:44:28 --> URI Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Router Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Output Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Input Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 16:44:28 --> Language Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Loader Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Controller Class Initialized
ERROR - 2011-10-04 16:44:28 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 16:44:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 16:44:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 16:44:28 --> Model Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Model Class Initialized
DEBUG - 2011-10-04 16:44:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 16:44:28 --> Database Driver Class Initialized
DEBUG - 2011-10-04 16:44:28 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 16:44:28 --> Helper loaded: url_helper
DEBUG - 2011-10-04 16:44:28 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 16:44:28 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 16:44:28 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 16:44:28 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 16:44:28 --> Final output sent to browser
DEBUG - 2011-10-04 16:44:28 --> Total execution time: 0.5134
DEBUG - 2011-10-04 18:01:44 --> Config Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Hooks Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Utf8 Class Initialized
DEBUG - 2011-10-04 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 18:01:44 --> URI Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Router Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Output Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Input Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 18:01:44 --> Language Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Loader Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Controller Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Model Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Model Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Model Class Initialized
DEBUG - 2011-10-04 18:01:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 18:01:44 --> Database Driver Class Initialized
DEBUG - 2011-10-04 18:01:48 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 18:01:48 --> Helper loaded: url_helper
DEBUG - 2011-10-04 18:01:48 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 18:01:48 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 18:01:48 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 18:01:48 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 18:01:48 --> Final output sent to browser
DEBUG - 2011-10-04 18:01:48 --> Total execution time: 3.5417
DEBUG - 2011-10-04 18:01:52 --> Config Class Initialized
DEBUG - 2011-10-04 18:01:52 --> Hooks Class Initialized
DEBUG - 2011-10-04 18:01:52 --> Utf8 Class Initialized
DEBUG - 2011-10-04 18:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 18:01:52 --> URI Class Initialized
DEBUG - 2011-10-04 18:01:52 --> Router Class Initialized
ERROR - 2011-10-04 18:01:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 18:01:52 --> Config Class Initialized
DEBUG - 2011-10-04 18:01:52 --> Hooks Class Initialized
DEBUG - 2011-10-04 18:01:52 --> Utf8 Class Initialized
DEBUG - 2011-10-04 18:01:52 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 18:01:52 --> URI Class Initialized
DEBUG - 2011-10-04 18:01:52 --> Router Class Initialized
ERROR - 2011-10-04 18:01:52 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 18:02:20 --> Config Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Hooks Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Utf8 Class Initialized
DEBUG - 2011-10-04 18:02:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 18:02:20 --> URI Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Router Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Output Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Input Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 18:02:20 --> Language Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Loader Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Controller Class Initialized
ERROR - 2011-10-04 18:02:20 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 18:02:20 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 18:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 18:02:20 --> Model Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Model Class Initialized
DEBUG - 2011-10-04 18:02:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 18:02:20 --> Database Driver Class Initialized
DEBUG - 2011-10-04 18:02:20 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 18:02:20 --> Helper loaded: url_helper
DEBUG - 2011-10-04 18:02:20 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 18:02:20 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 18:02:20 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 18:02:20 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 18:02:20 --> Final output sent to browser
DEBUG - 2011-10-04 18:02:20 --> Total execution time: 0.0473
DEBUG - 2011-10-04 18:02:21 --> Config Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Hooks Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Utf8 Class Initialized
DEBUG - 2011-10-04 18:02:21 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 18:02:21 --> URI Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Router Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Output Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Input Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 18:02:21 --> Language Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Loader Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Controller Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Model Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Model Class Initialized
DEBUG - 2011-10-04 18:02:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 18:02:21 --> Database Driver Class Initialized
DEBUG - 2011-10-04 18:02:22 --> Final output sent to browser
DEBUG - 2011-10-04 18:02:22 --> Total execution time: 0.7384
DEBUG - 2011-10-04 18:02:23 --> Config Class Initialized
DEBUG - 2011-10-04 18:02:23 --> Hooks Class Initialized
DEBUG - 2011-10-04 18:02:23 --> Utf8 Class Initialized
DEBUG - 2011-10-04 18:02:23 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 18:02:23 --> URI Class Initialized
DEBUG - 2011-10-04 18:02:23 --> Router Class Initialized
ERROR - 2011-10-04 18:02:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-10-04 19:53:18 --> Config Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Hooks Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Utf8 Class Initialized
DEBUG - 2011-10-04 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 19:53:18 --> URI Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Router Class Initialized
ERROR - 2011-10-04 19:53:18 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-10-04 19:53:18 --> Config Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Hooks Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Utf8 Class Initialized
DEBUG - 2011-10-04 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 19:53:18 --> URI Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Router Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Output Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Input Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 19:53:18 --> Language Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Loader Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Controller Class Initialized
ERROR - 2011-10-04 19:53:18 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 19:53:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 19:53:18 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 19:53:18 --> Model Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Model Class Initialized
DEBUG - 2011-10-04 19:53:18 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 19:53:18 --> Database Driver Class Initialized
DEBUG - 2011-10-04 19:53:19 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 19:53:19 --> Helper loaded: url_helper
DEBUG - 2011-10-04 19:53:19 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 19:53:19 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 19:53:19 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 19:53:19 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 19:53:19 --> Final output sent to browser
DEBUG - 2011-10-04 19:53:19 --> Total execution time: 0.7010
DEBUG - 2011-10-04 19:53:20 --> Config Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Hooks Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Utf8 Class Initialized
DEBUG - 2011-10-04 19:53:20 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 19:53:20 --> URI Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Router Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Output Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Input Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 19:53:20 --> Language Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Loader Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Controller Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Model Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Model Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Model Class Initialized
DEBUG - 2011-10-04 19:53:20 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 19:53:20 --> Database Driver Class Initialized
DEBUG - 2011-10-04 19:53:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 19:53:21 --> Helper loaded: url_helper
DEBUG - 2011-10-04 19:53:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 19:53:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 19:53:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 19:53:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 19:53:21 --> Final output sent to browser
DEBUG - 2011-10-04 19:53:21 --> Total execution time: 0.5992
DEBUG - 2011-10-04 21:51:07 --> Config Class Initialized
DEBUG - 2011-10-04 21:51:07 --> Hooks Class Initialized
DEBUG - 2011-10-04 21:51:07 --> Utf8 Class Initialized
DEBUG - 2011-10-04 21:51:07 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 21:51:07 --> URI Class Initialized
DEBUG - 2011-10-04 21:51:07 --> Router Class Initialized
DEBUG - 2011-10-04 21:51:07 --> No URI present. Default controller set.
DEBUG - 2011-10-04 21:51:07 --> Output Class Initialized
DEBUG - 2011-10-04 21:51:07 --> Input Class Initialized
DEBUG - 2011-10-04 21:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 21:51:07 --> Language Class Initialized
DEBUG - 2011-10-04 21:51:07 --> Loader Class Initialized
DEBUG - 2011-10-04 21:51:07 --> Controller Class Initialized
DEBUG - 2011-10-04 21:51:07 --> File loaded: application/views/splash/main.php
DEBUG - 2011-10-04 21:51:07 --> Helper loaded: url_helper
DEBUG - 2011-10-04 21:51:07 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 21:51:07 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 21:51:07 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 21:51:07 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 21:51:07 --> Final output sent to browser
DEBUG - 2011-10-04 21:51:07 --> Total execution time: 0.1346
DEBUG - 2011-10-04 23:22:41 --> Config Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Hooks Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Utf8 Class Initialized
DEBUG - 2011-10-04 23:22:41 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 23:22:41 --> URI Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Router Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Output Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Input Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 23:22:41 --> Language Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Loader Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Controller Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Model Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Model Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Model Class Initialized
DEBUG - 2011-10-04 23:22:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 23:22:41 --> Database Driver Class Initialized
DEBUG - 2011-10-04 23:22:42 --> File loaded: application/views/table/main.php
DEBUG - 2011-10-04 23:22:42 --> Helper loaded: url_helper
DEBUG - 2011-10-04 23:22:42 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 23:22:42 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 23:22:42 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 23:22:42 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 23:22:42 --> Final output sent to browser
DEBUG - 2011-10-04 23:22:42 --> Total execution time: 0.9814
DEBUG - 2011-10-04 23:22:44 --> Config Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Hooks Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Utf8 Class Initialized
DEBUG - 2011-10-04 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2011-10-04 23:22:44 --> URI Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Router Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Output Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Input Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-10-04 23:22:44 --> Language Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Loader Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Controller Class Initialized
ERROR - 2011-10-04 23:22:44 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-10-04 23:22:44 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-10-04 23:22:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 23:22:44 --> Model Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Model Class Initialized
DEBUG - 2011-10-04 23:22:44 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-10-04 23:22:44 --> Database Driver Class Initialized
DEBUG - 2011-10-04 23:22:44 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-10-04 23:22:44 --> Helper loaded: url_helper
DEBUG - 2011-10-04 23:22:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-10-04 23:22:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-10-04 23:22:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-10-04 23:22:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-10-04 23:22:44 --> Final output sent to browser
DEBUG - 2011-10-04 23:22:44 --> Total execution time: 0.0834

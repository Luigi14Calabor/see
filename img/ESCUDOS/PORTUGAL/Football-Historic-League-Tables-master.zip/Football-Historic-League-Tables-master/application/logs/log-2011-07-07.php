<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-07-07 02:38:52 --> Config Class Initialized
DEBUG - 2011-07-07 02:38:52 --> Hooks Class Initialized
DEBUG - 2011-07-07 02:38:52 --> Utf8 Class Initialized
DEBUG - 2011-07-07 02:38:52 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 02:38:52 --> URI Class Initialized
DEBUG - 2011-07-07 02:38:52 --> Router Class Initialized
ERROR - 2011-07-07 02:38:52 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-07 07:39:53 --> Config Class Initialized
DEBUG - 2011-07-07 07:39:53 --> Hooks Class Initialized
DEBUG - 2011-07-07 07:39:53 --> Utf8 Class Initialized
DEBUG - 2011-07-07 07:39:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 07:39:53 --> URI Class Initialized
DEBUG - 2011-07-07 07:39:53 --> Router Class Initialized
DEBUG - 2011-07-07 07:39:53 --> No URI present. Default controller set.
DEBUG - 2011-07-07 07:39:53 --> Output Class Initialized
DEBUG - 2011-07-07 07:39:53 --> Input Class Initialized
DEBUG - 2011-07-07 07:39:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 07:39:53 --> Language Class Initialized
DEBUG - 2011-07-07 07:39:53 --> Loader Class Initialized
DEBUG - 2011-07-07 07:39:53 --> Controller Class Initialized
DEBUG - 2011-07-07 07:39:53 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-07 07:39:53 --> Helper loaded: url_helper
DEBUG - 2011-07-07 07:39:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 07:39:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 07:39:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 07:39:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 07:39:53 --> Final output sent to browser
DEBUG - 2011-07-07 07:39:53 --> Total execution time: 0.3927
DEBUG - 2011-07-07 07:42:09 --> Config Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Hooks Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Utf8 Class Initialized
DEBUG - 2011-07-07 07:42:09 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 07:42:09 --> URI Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Router Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Output Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Input Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 07:42:09 --> Language Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Loader Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Controller Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Model Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Model Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Model Class Initialized
DEBUG - 2011-07-07 07:42:09 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 07:42:10 --> Database Driver Class Initialized
DEBUG - 2011-07-07 07:42:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 07:42:12 --> Helper loaded: url_helper
DEBUG - 2011-07-07 07:42:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 07:42:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 07:42:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 07:42:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 07:42:12 --> Final output sent to browser
DEBUG - 2011-07-07 07:42:12 --> Total execution time: 2.9748
DEBUG - 2011-07-07 07:42:19 --> Config Class Initialized
DEBUG - 2011-07-07 07:42:19 --> Hooks Class Initialized
DEBUG - 2011-07-07 07:42:19 --> Utf8 Class Initialized
DEBUG - 2011-07-07 07:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 07:42:19 --> URI Class Initialized
DEBUG - 2011-07-07 07:42:19 --> Router Class Initialized
ERROR - 2011-07-07 07:42:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-07 07:42:19 --> Config Class Initialized
DEBUG - 2011-07-07 07:42:19 --> Hooks Class Initialized
DEBUG - 2011-07-07 07:42:19 --> Utf8 Class Initialized
DEBUG - 2011-07-07 07:42:19 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 07:42:19 --> URI Class Initialized
DEBUG - 2011-07-07 07:42:19 --> Router Class Initialized
ERROR - 2011-07-07 07:42:19 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-07 08:16:44 --> Config Class Initialized
DEBUG - 2011-07-07 08:16:44 --> Hooks Class Initialized
DEBUG - 2011-07-07 08:16:44 --> Utf8 Class Initialized
DEBUG - 2011-07-07 08:16:44 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 08:16:44 --> URI Class Initialized
DEBUG - 2011-07-07 08:16:44 --> Router Class Initialized
DEBUG - 2011-07-07 08:16:44 --> Output Class Initialized
DEBUG - 2011-07-07 08:16:44 --> Input Class Initialized
DEBUG - 2011-07-07 08:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 08:16:44 --> Language Class Initialized
DEBUG - 2011-07-07 08:16:45 --> Loader Class Initialized
DEBUG - 2011-07-07 08:16:45 --> Controller Class Initialized
DEBUG - 2011-07-07 08:16:45 --> Model Class Initialized
DEBUG - 2011-07-07 08:16:45 --> Model Class Initialized
DEBUG - 2011-07-07 08:16:45 --> Model Class Initialized
DEBUG - 2011-07-07 08:16:45 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 08:16:45 --> Database Driver Class Initialized
DEBUG - 2011-07-07 08:16:45 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 08:16:45 --> Helper loaded: url_helper
DEBUG - 2011-07-07 08:16:45 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 08:16:45 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 08:16:45 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 08:16:45 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 08:16:45 --> Final output sent to browser
DEBUG - 2011-07-07 08:16:45 --> Total execution time: 0.7907
DEBUG - 2011-07-07 09:33:10 --> Config Class Initialized
DEBUG - 2011-07-07 09:33:10 --> Hooks Class Initialized
DEBUG - 2011-07-07 09:33:10 --> Utf8 Class Initialized
DEBUG - 2011-07-07 09:33:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 09:33:10 --> URI Class Initialized
DEBUG - 2011-07-07 09:33:10 --> Router Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Output Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Input Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 09:33:11 --> Language Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Loader Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Controller Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Model Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Model Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Model Class Initialized
DEBUG - 2011-07-07 09:33:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 09:33:11 --> Database Driver Class Initialized
DEBUG - 2011-07-07 09:33:11 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 09:33:11 --> Helper loaded: url_helper
DEBUG - 2011-07-07 09:33:11 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 09:33:11 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 09:33:11 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 09:33:11 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 09:33:11 --> Final output sent to browser
DEBUG - 2011-07-07 09:33:11 --> Total execution time: 0.6532
DEBUG - 2011-07-07 10:35:10 --> Config Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Hooks Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Utf8 Class Initialized
DEBUG - 2011-07-07 10:35:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 10:35:10 --> URI Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Router Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Output Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Input Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 10:35:10 --> Language Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Loader Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Controller Class Initialized
ERROR - 2011-07-07 10:35:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 10:35:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 10:35:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 10:35:10 --> Model Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Model Class Initialized
DEBUG - 2011-07-07 10:35:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 10:35:10 --> Database Driver Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Config Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Hooks Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Utf8 Class Initialized
DEBUG - 2011-07-07 10:40:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 10:40:27 --> URI Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Router Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Output Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Input Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 10:40:27 --> Language Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Loader Class Initialized
DEBUG - 2011-07-07 10:40:27 --> Controller Class Initialized
ERROR - 2011-07-07 10:40:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 10:40:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 10:40:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 10:40:28 --> Model Class Initialized
DEBUG - 2011-07-07 10:40:28 --> Model Class Initialized
DEBUG - 2011-07-07 10:40:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 10:40:28 --> Database Driver Class Initialized
ERROR - 2011-07-07 10:40:28 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-07-07 10:40:28 --> Unable to connect to the database
DEBUG - 2011-07-07 10:40:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-07-07 10:45:12 --> Config Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Hooks Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Utf8 Class Initialized
DEBUG - 2011-07-07 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 10:45:12 --> URI Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Router Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Output Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Input Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 10:45:12 --> Language Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Loader Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Controller Class Initialized
ERROR - 2011-07-07 10:45:12 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 10:45:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 10:45:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 10:45:12 --> Model Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Model Class Initialized
DEBUG - 2011-07-07 10:45:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 10:45:12 --> Database Driver Class Initialized
ERROR - 2011-07-07 10:45:12 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/var/lib/mysql/mysql.sock' (11) /home1/raptorsr/public_html/arsenaliststats/system/database/drivers/mysql/mysql_driver.php 88
ERROR - 2011-07-07 10:45:12 --> Unable to connect to the database
DEBUG - 2011-07-07 10:45:12 --> Language file loaded: language/english/db_lang.php
DEBUG - 2011-07-07 12:32:28 --> Config Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Hooks Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Utf8 Class Initialized
DEBUG - 2011-07-07 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 12:32:28 --> URI Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Router Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Output Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Input Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 12:32:28 --> Language Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Loader Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Controller Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Model Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Model Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Model Class Initialized
DEBUG - 2011-07-07 12:32:28 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 12:32:28 --> Database Driver Class Initialized
DEBUG - 2011-07-07 12:32:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 12:32:30 --> Helper loaded: url_helper
DEBUG - 2011-07-07 12:32:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 12:32:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 12:32:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 12:32:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 12:32:30 --> Final output sent to browser
DEBUG - 2011-07-07 12:32:30 --> Total execution time: 1.8894
DEBUG - 2011-07-07 13:18:51 --> Config Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Hooks Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Utf8 Class Initialized
DEBUG - 2011-07-07 13:18:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 13:18:51 --> URI Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Router Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Output Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Input Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 13:18:51 --> Language Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Loader Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Controller Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Model Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Model Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Model Class Initialized
DEBUG - 2011-07-07 13:18:51 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 13:18:51 --> Database Driver Class Initialized
DEBUG - 2011-07-07 13:18:51 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 13:18:51 --> Helper loaded: url_helper
DEBUG - 2011-07-07 13:18:51 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 13:18:51 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 13:18:51 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 13:18:51 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 13:18:51 --> Final output sent to browser
DEBUG - 2011-07-07 13:18:51 --> Total execution time: 0.5576
DEBUG - 2011-07-07 13:18:54 --> Config Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Hooks Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Utf8 Class Initialized
DEBUG - 2011-07-07 13:18:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 13:18:54 --> URI Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Router Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Output Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Input Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 13:18:54 --> Language Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Loader Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Controller Class Initialized
ERROR - 2011-07-07 13:18:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 13:18:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 13:18:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 13:18:54 --> Model Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Model Class Initialized
DEBUG - 2011-07-07 13:18:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 13:18:54 --> Database Driver Class Initialized
DEBUG - 2011-07-07 13:18:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 13:18:54 --> Helper loaded: url_helper
DEBUG - 2011-07-07 13:18:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 13:18:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 13:18:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 13:18:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 13:18:54 --> Final output sent to browser
DEBUG - 2011-07-07 13:18:54 --> Total execution time: 0.1287
DEBUG - 2011-07-07 14:34:59 --> Config Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:34:59 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:34:59 --> URI Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Router Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Output Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Input Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 14:34:59 --> Language Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Loader Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Controller Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Model Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Model Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Model Class Initialized
DEBUG - 2011-07-07 14:34:59 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 14:34:59 --> Database Driver Class Initialized
DEBUG - 2011-07-07 14:34:59 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 14:34:59 --> Helper loaded: url_helper
DEBUG - 2011-07-07 14:34:59 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 14:34:59 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 14:34:59 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 14:34:59 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 14:34:59 --> Final output sent to browser
DEBUG - 2011-07-07 14:34:59 --> Total execution time: 0.5310
DEBUG - 2011-07-07 14:35:01 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:01 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:01 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:01 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:01 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:01 --> Router Class Initialized
ERROR - 2011-07-07 14:35:01 --> 404 Page Not Found --> robots.txt
DEBUG - 2011-07-07 14:35:02 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:02 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Router Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Output Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Input Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 14:35:02 --> Language Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:02 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:02 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Router Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Loader Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Controller Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:02 --> Database config for development environment is not found. Trying global config.
ERROR - 2011-07-07 14:35:02 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-07 14:35:02 --> Database Driver Class Initialized
DEBUG - 2011-07-07 14:35:02 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 14:35:02 --> Helper loaded: url_helper
DEBUG - 2011-07-07 14:35:02 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 14:35:02 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 14:35:02 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 14:35:02 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 14:35:02 --> Final output sent to browser
DEBUG - 2011-07-07 14:35:02 --> Total execution time: 0.2761
DEBUG - 2011-07-07 14:35:11 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:11 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Router Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Output Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Input Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 14:35:11 --> Language Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Loader Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Controller Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 14:35:11 --> Database Driver Class Initialized
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 14:35:12 --> Helper loaded: url_helper
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 14:35:12 --> Final output sent to browser
DEBUG - 2011-07-07 14:35:12 --> Total execution time: 0.5425
DEBUG - 2011-07-07 14:35:12 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:12 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:12 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Router Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Output Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Input Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 14:35:12 --> Language Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Loader Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Controller Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:12 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 14:35:12 --> Database Driver Class Initialized
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 14:35:12 --> Helper loaded: url_helper
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 14:35:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 14:35:12 --> Final output sent to browser
DEBUG - 2011-07-07 14:35:12 --> Total execution time: 0.0477
DEBUG - 2011-07-07 14:35:13 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:13 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:13 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:13 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:13 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:13 --> Router Class Initialized
ERROR - 2011-07-07 14:35:13 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-07 14:35:21 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:21 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:21 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Router Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Output Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Input Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 14:35:21 --> Language Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Loader Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Controller Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:21 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 14:35:21 --> Database Driver Class Initialized
DEBUG - 2011-07-07 14:35:21 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 14:35:21 --> Helper loaded: url_helper
DEBUG - 2011-07-07 14:35:21 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 14:35:21 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 14:35:21 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 14:35:21 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 14:35:21 --> Final output sent to browser
DEBUG - 2011-07-07 14:35:21 --> Total execution time: 0.2559
DEBUG - 2011-07-07 14:35:22 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:22 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:22 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Router Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Output Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Input Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 14:35:22 --> Language Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Loader Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Controller Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:22 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 14:35:22 --> Database Driver Class Initialized
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 14:35:23 --> Helper loaded: url_helper
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 14:35:23 --> Final output sent to browser
DEBUG - 2011-07-07 14:35:23 --> Total execution time: 0.1397
DEBUG - 2011-07-07 14:35:23 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:23 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Router Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Output Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Input Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 14:35:23 --> Language Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Loader Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Controller Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Model Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 14:35:23 --> Database Driver Class Initialized
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 14:35:23 --> Helper loaded: url_helper
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 14:35:23 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 14:35:23 --> Final output sent to browser
DEBUG - 2011-07-07 14:35:23 --> Total execution time: 0.0462
DEBUG - 2011-07-07 14:35:23 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:23 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Router Class Initialized
ERROR - 2011-07-07 14:35:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-07 14:35:23 --> Config Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Hooks Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Utf8 Class Initialized
DEBUG - 2011-07-07 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 14:35:23 --> URI Class Initialized
DEBUG - 2011-07-07 14:35:23 --> Router Class Initialized
ERROR - 2011-07-07 14:35:23 --> 404 Page Not Found --> favicon.ico
DEBUG - 2011-07-07 15:56:14 --> Config Class Initialized
DEBUG - 2011-07-07 15:56:14 --> Hooks Class Initialized
DEBUG - 2011-07-07 15:56:14 --> Utf8 Class Initialized
DEBUG - 2011-07-07 15:56:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 15:56:14 --> URI Class Initialized
DEBUG - 2011-07-07 15:56:14 --> Router Class Initialized
DEBUG - 2011-07-07 15:56:14 --> Output Class Initialized
DEBUG - 2011-07-07 15:56:14 --> Input Class Initialized
DEBUG - 2011-07-07 15:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 15:56:14 --> Language Class Initialized
DEBUG - 2011-07-07 15:56:15 --> Loader Class Initialized
DEBUG - 2011-07-07 15:56:15 --> Controller Class Initialized
ERROR - 2011-07-07 15:56:15 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 15:56:15 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 15:56:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 15:56:15 --> Model Class Initialized
DEBUG - 2011-07-07 15:56:15 --> Model Class Initialized
DEBUG - 2011-07-07 15:56:15 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 15:56:15 --> Database Driver Class Initialized
DEBUG - 2011-07-07 15:56:15 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 15:56:15 --> Helper loaded: url_helper
DEBUG - 2011-07-07 15:56:15 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 15:56:15 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 15:56:15 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 15:56:15 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 15:56:15 --> Final output sent to browser
DEBUG - 2011-07-07 15:56:15 --> Total execution time: 0.3820
DEBUG - 2011-07-07 15:59:15 --> Config Class Initialized
DEBUG - 2011-07-07 15:59:15 --> Hooks Class Initialized
DEBUG - 2011-07-07 15:59:15 --> Utf8 Class Initialized
DEBUG - 2011-07-07 15:59:15 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 15:59:15 --> URI Class Initialized
DEBUG - 2011-07-07 15:59:15 --> Router Class Initialized
DEBUG - 2011-07-07 15:59:15 --> No URI present. Default controller set.
DEBUG - 2011-07-07 15:59:15 --> Output Class Initialized
DEBUG - 2011-07-07 15:59:15 --> Input Class Initialized
DEBUG - 2011-07-07 15:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 15:59:15 --> Language Class Initialized
DEBUG - 2011-07-07 15:59:15 --> Loader Class Initialized
DEBUG - 2011-07-07 15:59:15 --> Controller Class Initialized
DEBUG - 2011-07-07 15:59:16 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-07 15:59:16 --> Helper loaded: url_helper
DEBUG - 2011-07-07 15:59:16 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 15:59:16 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 15:59:16 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 15:59:16 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 15:59:16 --> Final output sent to browser
DEBUG - 2011-07-07 15:59:16 --> Total execution time: 1.3079
DEBUG - 2011-07-07 17:09:50 --> Config Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Hooks Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Utf8 Class Initialized
DEBUG - 2011-07-07 17:09:50 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 17:09:50 --> URI Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Router Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Output Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Input Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 17:09:50 --> Language Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Loader Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Controller Class Initialized
ERROR - 2011-07-07 17:09:50 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 17:09:50 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 17:09:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 17:09:50 --> Model Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Model Class Initialized
DEBUG - 2011-07-07 17:09:50 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 17:09:50 --> Database Driver Class Initialized
DEBUG - 2011-07-07 17:09:50 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 17:09:50 --> Helper loaded: url_helper
DEBUG - 2011-07-07 17:09:50 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 17:09:50 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 17:09:50 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 17:09:50 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 17:09:50 --> Final output sent to browser
DEBUG - 2011-07-07 17:09:50 --> Total execution time: 0.3319
DEBUG - 2011-07-07 17:09:54 --> Config Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Hooks Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Utf8 Class Initialized
DEBUG - 2011-07-07 17:09:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 17:09:54 --> URI Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Router Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Output Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Input Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 17:09:54 --> Language Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Loader Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Controller Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Model Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Model Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 17:09:54 --> Database Driver Class Initialized
DEBUG - 2011-07-07 17:09:54 --> Final output sent to browser
DEBUG - 2011-07-07 17:09:54 --> Total execution time: 0.5403
DEBUG - 2011-07-07 19:42:51 --> Config Class Initialized
DEBUG - 2011-07-07 19:42:51 --> Hooks Class Initialized
DEBUG - 2011-07-07 19:42:51 --> Utf8 Class Initialized
DEBUG - 2011-07-07 19:42:51 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 19:42:51 --> URI Class Initialized
DEBUG - 2011-07-07 19:42:51 --> Router Class Initialized
DEBUG - 2011-07-07 19:42:51 --> Output Class Initialized
DEBUG - 2011-07-07 19:42:51 --> Input Class Initialized
DEBUG - 2011-07-07 19:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 19:42:51 --> Language Class Initialized
DEBUG - 2011-07-07 19:42:52 --> Loader Class Initialized
DEBUG - 2011-07-07 19:42:52 --> Controller Class Initialized
DEBUG - 2011-07-07 19:42:52 --> Model Class Initialized
DEBUG - 2011-07-07 19:42:52 --> Model Class Initialized
DEBUG - 2011-07-07 19:42:52 --> Model Class Initialized
DEBUG - 2011-07-07 19:42:52 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 19:42:52 --> Database Driver Class Initialized
DEBUG - 2011-07-07 19:42:52 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 19:42:52 --> Helper loaded: url_helper
DEBUG - 2011-07-07 19:42:52 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 19:42:52 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 19:42:52 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 19:42:52 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 19:42:52 --> Final output sent to browser
DEBUG - 2011-07-07 19:42:52 --> Total execution time: 0.5991
DEBUG - 2011-07-07 21:20:03 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:03 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:03 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:03 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:03 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:03 --> No URI present. Default controller set.
DEBUG - 2011-07-07 21:20:03 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:03 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:03 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:03 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:03 --> Controller Class Initialized
DEBUG - 2011-07-07 21:20:03 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-07 21:20:03 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:03 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:03 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:03 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:03 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:03 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:03 --> Total execution time: 0.2910
DEBUG - 2011-07-07 21:20:10 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:10 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:10 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Controller Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:10 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:10 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:10 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Controller Class Initialized
ERROR - 2011-07-07 21:20:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:20:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:10 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:10 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:10 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:10 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:10 --> Total execution time: 0.1276
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 21:20:10 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:10 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:10 --> Total execution time: 0.7496
DEBUG - 2011-07-07 21:20:11 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:11 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:11 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Controller Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:11 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:12 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:12 --> Total execution time: 0.6619
DEBUG - 2011-07-07 21:20:33 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:33 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:33 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:33 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Controller Class Initialized
ERROR - 2011-07-07 21:20:33 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:20:33 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:20:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:33 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:33 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:33 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:33 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:33 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:33 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:33 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:33 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:33 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:33 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:33 --> Total execution time: 0.0417
DEBUG - 2011-07-07 21:20:34 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:34 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:34 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Controller Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:34 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:35 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:35 --> Total execution time: 0.9828
DEBUG - 2011-07-07 21:20:37 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:37 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:37 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:37 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:37 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:37 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:37 --> No URI present. Default controller set.
DEBUG - 2011-07-07 21:20:37 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:37 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:37 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:37 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:37 --> Controller Class Initialized
DEBUG - 2011-07-07 21:20:37 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-07 21:20:37 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:37 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:37 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:37 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:37 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:37 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:37 --> Total execution time: 0.0136
DEBUG - 2011-07-07 21:20:41 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:41 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:41 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:41 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Controller Class Initialized
ERROR - 2011-07-07 21:20:41 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:20:41 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:41 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:41 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:41 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:41 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:41 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:41 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:41 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:41 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:41 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:41 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:41 --> Total execution time: 0.0286
DEBUG - 2011-07-07 21:20:53 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:53 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:53 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:53 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Controller Class Initialized
ERROR - 2011-07-07 21:20:53 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:20:53 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:20:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:53 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:53 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:53 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:53 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:53 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:53 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:53 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:53 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:53 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:53 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:53 --> Total execution time: 0.0317
DEBUG - 2011-07-07 21:20:54 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:54 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:54 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Controller Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:54 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:54 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:54 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Controller Class Initialized
ERROR - 2011-07-07 21:20:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:20:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:54 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:54 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:54 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:54 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:54 --> Total execution time: 0.0387
DEBUG - 2011-07-07 21:20:54 --> Config Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:20:54 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:20:54 --> URI Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Router Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Output Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Input Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:20:54 --> Language Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Loader Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Controller Class Initialized
ERROR - 2011-07-07 21:20:54 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:20:54 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:54 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Model Class Initialized
DEBUG - 2011-07-07 21:20:54 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:20:54 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:20:54 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:20:54 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:20:54 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:54 --> Total execution time: 0.0280
DEBUG - 2011-07-07 21:20:55 --> Final output sent to browser
DEBUG - 2011-07-07 21:20:55 --> Total execution time: 0.7451
DEBUG - 2011-07-07 21:21:10 --> Config Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:21:10 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:21:10 --> URI Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Router Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Output Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Input Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:21:10 --> Language Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Loader Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Controller Class Initialized
ERROR - 2011-07-07 21:21:10 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:21:10 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:21:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:21:10 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:10 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:21:10 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:21:10 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:21:10 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:21:10 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:21:10 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:21:10 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:21:10 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:21:10 --> Final output sent to browser
DEBUG - 2011-07-07 21:21:10 --> Total execution time: 0.0665
DEBUG - 2011-07-07 21:21:11 --> Config Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:21:11 --> URI Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Router Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Output Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Input Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:21:11 --> Language Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Loader Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Controller Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:21:11 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Config Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:21:11 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:21:11 --> URI Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Router Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Output Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Input Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:21:11 --> Language Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Loader Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Controller Class Initialized
ERROR - 2011-07-07 21:21:11 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:21:11 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:21:11 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:21:11 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:11 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:21:12 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:21:12 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:21:12 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:21:12 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:21:12 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:21:12 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:21:12 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:21:12 --> Final output sent to browser
DEBUG - 2011-07-07 21:21:12 --> Total execution time: 0.0271
DEBUG - 2011-07-07 21:21:12 --> Final output sent to browser
DEBUG - 2011-07-07 21:21:12 --> Total execution time: 1.3129
DEBUG - 2011-07-07 21:21:27 --> Config Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:21:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:21:27 --> URI Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Router Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Output Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Input Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:21:27 --> Language Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Loader Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Controller Class Initialized
ERROR - 2011-07-07 21:21:27 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:21:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:21:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:21:27 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:27 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:21:27 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:21:27 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:21:27 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:21:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:21:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:21:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:21:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:21:27 --> Final output sent to browser
DEBUG - 2011-07-07 21:21:27 --> Total execution time: 0.1123
DEBUG - 2011-07-07 21:21:29 --> Config Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:21:29 --> URI Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Router Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Output Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Input Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:21:29 --> Language Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Loader Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Controller Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:21:29 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Config Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:21:29 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:21:29 --> URI Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Router Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Output Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Input Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:21:29 --> Language Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Loader Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Controller Class Initialized
ERROR - 2011-07-07 21:21:29 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:21:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:21:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:21:29 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Model Class Initialized
DEBUG - 2011-07-07 21:21:29 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:21:29 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:21:29 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:21:29 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:21:29 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:21:29 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:21:29 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:21:29 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:21:29 --> Final output sent to browser
DEBUG - 2011-07-07 21:21:29 --> Total execution time: 0.0786
DEBUG - 2011-07-07 21:21:30 --> Final output sent to browser
DEBUG - 2011-07-07 21:21:30 --> Total execution time: 0.9463
DEBUG - 2011-07-07 21:22:03 --> Config Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:22:03 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:22:03 --> URI Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Router Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Output Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Input Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:22:03 --> Language Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Loader Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Controller Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Model Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Model Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Model Class Initialized
DEBUG - 2011-07-07 21:22:03 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:22:03 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:22:04 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 21:22:04 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:22:04 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:22:04 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:22:04 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:22:04 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:22:04 --> Final output sent to browser
DEBUG - 2011-07-07 21:22:04 --> Total execution time: 0.3602
DEBUG - 2011-07-07 21:22:05 --> Config Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:22:05 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:22:05 --> URI Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Router Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Output Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Input Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:22:05 --> Language Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Loader Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Controller Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Model Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Model Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Model Class Initialized
DEBUG - 2011-07-07 21:22:05 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:22:05 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:22:05 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 21:22:05 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:22:05 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:22:05 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:22:05 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:22:05 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:22:05 --> Final output sent to browser
DEBUG - 2011-07-07 21:22:05 --> Total execution time: 0.0457
DEBUG - 2011-07-07 21:32:14 --> Config Class Initialized
DEBUG - 2011-07-07 21:32:14 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:32:14 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:32:14 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:32:14 --> URI Class Initialized
DEBUG - 2011-07-07 21:32:14 --> Router Class Initialized
DEBUG - 2011-07-07 21:32:14 --> No URI present. Default controller set.
DEBUG - 2011-07-07 21:32:14 --> Output Class Initialized
DEBUG - 2011-07-07 21:32:14 --> Input Class Initialized
DEBUG - 2011-07-07 21:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:32:14 --> Language Class Initialized
DEBUG - 2011-07-07 21:32:14 --> Loader Class Initialized
DEBUG - 2011-07-07 21:32:14 --> Controller Class Initialized
DEBUG - 2011-07-07 21:32:14 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-07 21:32:14 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:32:14 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:32:14 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:32:14 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:32:14 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:32:14 --> Final output sent to browser
DEBUG - 2011-07-07 21:32:14 --> Total execution time: 0.0124
DEBUG - 2011-07-07 21:37:43 --> Config Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:37:43 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:37:43 --> URI Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Router Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Output Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Input Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:37:43 --> Language Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Loader Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Controller Class Initialized
ERROR - 2011-07-07 21:37:43 --> Severity: Notice  --> Undefined variable: leagues /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
ERROR - 2011-07-07 21:37:43 --> Severity: Warning  --> Invalid argument supplied for foreach() /home1/raptorsr/public_html/arsenaliststats/application/views/snakes/main.php 12
DEBUG - 2011-07-07 21:37:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:37:43 --> Model Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Model Class Initialized
DEBUG - 2011-07-07 21:37:43 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:37:43 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:37:43 --> File loaded: application/views/snakes/main.php
DEBUG - 2011-07-07 21:37:44 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:37:44 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:37:44 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:37:44 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:37:44 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:37:44 --> Final output sent to browser
DEBUG - 2011-07-07 21:37:44 --> Total execution time: 0.0369
DEBUG - 2011-07-07 21:41:30 --> Config Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:41:30 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:41:30 --> URI Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Router Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Output Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Input Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:41:30 --> Language Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Loader Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Controller Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Model Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Model Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Model Class Initialized
DEBUG - 2011-07-07 21:41:30 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:41:30 --> Database Driver Class Initialized
DEBUG - 2011-07-07 21:41:30 --> File loaded: application/views/table/main.php
DEBUG - 2011-07-07 21:41:30 --> Helper loaded: url_helper
DEBUG - 2011-07-07 21:41:30 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 21:41:30 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 21:41:30 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 21:41:30 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 21:41:30 --> Final output sent to browser
DEBUG - 2011-07-07 21:41:30 --> Total execution time: 0.0574
DEBUG - 2011-07-07 21:55:34 --> Config Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Hooks Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Utf8 Class Initialized
DEBUG - 2011-07-07 21:55:34 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 21:55:34 --> URI Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Router Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Output Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Input Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 21:55:34 --> Language Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Loader Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Controller Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Model Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Model Class Initialized
DEBUG - 2011-07-07 21:55:34 --> Database config for development environment is not found. Trying global config.
DEBUG - 2011-07-07 21:55:34 --> Database Driver Class Initialized
DEBUG - 2011-07-07 22:12:27 --> Config Class Initialized
DEBUG - 2011-07-07 22:12:27 --> Hooks Class Initialized
DEBUG - 2011-07-07 22:12:27 --> Utf8 Class Initialized
DEBUG - 2011-07-07 22:12:27 --> UTF-8 Support Enabled
DEBUG - 2011-07-07 22:12:27 --> URI Class Initialized
DEBUG - 2011-07-07 22:12:27 --> Router Class Initialized
DEBUG - 2011-07-07 22:12:27 --> No URI present. Default controller set.
DEBUG - 2011-07-07 22:12:27 --> Output Class Initialized
DEBUG - 2011-07-07 22:12:27 --> Input Class Initialized
DEBUG - 2011-07-07 22:12:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-07-07 22:12:27 --> Language Class Initialized
DEBUG - 2011-07-07 22:12:27 --> Loader Class Initialized
DEBUG - 2011-07-07 22:12:27 --> Controller Class Initialized
DEBUG - 2011-07-07 22:12:27 --> File loaded: application/views/splash/main.php
DEBUG - 2011-07-07 22:12:27 --> Helper loaded: url_helper
DEBUG - 2011-07-07 22:12:27 --> File loaded: application/views/common/header.php
DEBUG - 2011-07-07 22:12:27 --> File loaded: application/views/common/sidebar.php
DEBUG - 2011-07-07 22:12:27 --> File loaded: application/views/common/footer.php
DEBUG - 2011-07-07 22:12:27 --> File loaded: application/views/layout/main.php
DEBUG - 2011-07-07 22:12:27 --> Final output sent to browser
DEBUG - 2011-07-07 22:12:27 --> Total execution time: 0.0680

Football Lineup Picker
